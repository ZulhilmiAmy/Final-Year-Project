<!DOCTYPE html>
<html lang="ms">

<head>
    <meta charset="UTF-8">
    <title>KPI 2 - Agensi Pemberi Bantuan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 20px;
        }

        .header {
            color: #fff;
            padding: 0;
            text-align: center;
            margin: -20px -20px 20px -20px;
        }

        .header img {
            width: 100%;
            max-height: 180px;
            object-fit: cover;
        }

        .top-bar {
            display: flex;
            background: #f8f9fa;
            padding: 8px 20px;
            border-bottom: 2px solid #204d84;
            font-size: 14px;
        }

        .breadcrumbs a {
            color: #204d84;
            text-decoration: none;
            font-weight: 500;
        }

        .breadcrumbs a:hover {
            text-decoration: underline;
        }

        .breadcrumbs .separator {
            color: #204d84;
            margin: 0 4px;
        }

        h1 {
            text-align: center;
            background: #204d84;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            font-size: 14px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 8px;
            text-align: center;
            vertical-align: middle;
        }

        th {
            background: #204d84;
            color: white;
        }

        td:nth-child(2),
        td:nth-child(6),
        td:nth-child(7),
        td:nth-child(8),
        td:nth-child(9) {
            width: 150px;
            text-align: center;
        }

        td:last-child {
            width: 140px;
            white-space: normal;
            word-wrap: break-word;
            text-align: center;
        }

        td:nth-child(7) {
            border-right: 2px solid #999;
        }

        td small {
            display: block;
            color: #555;
            font-size: 12px;
            margin-top: 2px;
        }

        .no-data {
            text-align: center;
            color: #888;
            padding: 12px;
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 18px;
            background: #204d84;
            color: white;
            border-radius: 6px;
            text-decoration: none;
        }

        .stat-row {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin: 30px 0;
        }

        .stat-card {
            flex: 1;
            background: #e3f2fd;
            color: #204d84;
            border-radius: 10px;
            text-align: center;
            padding: 15px;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }

        .stat-card h3 {
            margin: 10px 0 0;
            font-size: 26px;
        }

        @media (max-width: 768px) {
            .stat-row {
                flex-direction: column;
            }

            table {
                font-size: 12px;
            }
        }

        #scrollBottomBtn {
            position: fixed;
            right: 25px;
            bottom: 25px;
            background-color: #204d84;
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            font-size: 22px;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            display: none;
            z-index: 9999;
            transition: transform 0.2s ease, background-color 0.3s ease;
        }

        #scrollBottomBtn:hover {
            background-color: #2e6ab0;
            transform: scale(1.1);
        }
    </style>
</head>

<body>
    <div class="header">
        <img src="https://raw.githubusercontent.com/ZulhilmiAmy/Final-Year-Project/main/Banner/Banner-SPeKSi.png"
            alt="Banner">
        <div class="top-bar">
            <div class="breadcrumbs">
                <a>Log Masuk</a>
                <span class="separator">&gt;</span>
                <a href="{{ route('redirect') }}">Halaman Utama</a>
                <span class="separator">&gt;</span>
                <a>KPI 2</a>
            </div>
        </div>
    </div>

    <h1>KPI 2 - Statistik Kes Rujukan ke Agensi Pemberi Bantuan</h1>

    <!-- 🔹 Pilihan Bulan & Tahun -->
    <div style="text-align:center; margin-bottom:20px;">
        <form method="GET" action="{{ route('admin.kpi2') }}" style="display:inline-block; margin-right:15px;">
            <label for="bulan" style="font-weight:bold; color:#204d84;">Pilih Bulan:</label>
            <select name="bulan" id="bulan" onchange="this.form.submit()"
                style="padding:6px 10px; border-radius:6px; border:1px solid #204d84; font-size:14px; margin-left:8px;">
                <option value="all" {{ $bulan == 'all' ? 'selected' : '' }}>Semua Bulan</option>
                @for ($m = 1; $m <= 12; $m++)
                    <option value="{{ $m }}" {{ (string) $m === (string) $bulan ? 'selected' : '' }}>
                        {{ \Carbon\Carbon::create()->month($m)->translatedFormat('F') }}
                    </option>
                @endfor
            </select>

            <select name="tahun" id="tahun" onchange="this.form.submit()"
                style="padding:6px 10px; border-radius:6px; border:1px solid #204d84; font-size:14px; margin-left:8px;">
                @foreach($availableYears as $y)
                    <option value="{{ $y }}" {{ $y == $tahun ? 'selected' : '' }}>{{ $y }}</option>
                @endforeach
            </select>
        </form>

        <!-- 🖨️ Butang Print -->
        <button onclick="printKPI2()" style="
        background: #204d84;
        color: white;
        border: none;
        padding: 8px 14px;
        border-radius: 6px;
        cursor: pointer;
        font-size: 14px;
    ">
            🖨️ Cetak Laporan
        </button>
    </div>


    <div class="stat-row">
        <div class="stat-card">
            JUMLAH KES
            <h3>{{ $totalCases }}</h3>
        </div>
        <div class="stat-card">
            DALAM TEMPOH ≤ 5 HARI
            <h3>{{ $within5Days }}</h3>
        </div>
        <div class="stat-card">
            % KECEKAPAN
            <h3>{{ $percentage }}%</h3>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th rowspan="2">BIL</th>
                <th rowspan="2">NAMA PESAKIT</th>
                <th rowspan="2">NO FAIL</th>
                <th rowspan="2">TARIKH INTERVENSI SELESAI<br><small>(Dokumen Lengkap Diterima)</small></th>
                <th rowspan="2">TARIKH RUJUKAN DIHANTAR<br><small>(Tarikh Permohonan)</small></th>
                <th colspan="2">JENIS BANTUAN</th>
                <th colspan="3">AGENSI PEMBERI BANTUAN</th>
                <th colspan="2">TEMPOH MASA</th>
                <th rowspan="2">CATATAN</th>
            </tr>
            <tr>
                <th>BANTUAN PRAKTIK</th>
                <th>BANTUAN TERAPI SOKONGAN</th>
                <th>KERAJAAN</th>
                <th>BUKAN KERAJAAN</th>
                <th>JUMLAH BANTUAN (RM)</th>
                <th>≤ 5 HARI</th>
                <th>&gt; 5 HARI</th>
            </tr>
        </thead>
        <tbody>
            @forelse($patients as $index => $p)
                <tr>
                    <td>{{ $index + 1 }}</td>
                    <td>{{ $p->nama ?? '-' }}</td>
                    <td>{{ $p->no_fail ?? '-' }}</td>
                    <td>{{ $p->tarikh_dokumen_lengkap ? \Carbon\Carbon::parse($p->tarikh_dokumen_lengkap)->format('d/m/Y') : '-' }}
                    </td>
                    <td>{{ $p->tarikh_laporan ? \Carbon\Carbon::parse($p->tarikh_laporan)->format('d/m/Y') : '-' }}</td>
                    <td>
                        @if(is_array($p->bantuan_praktik))
                            {{ implode(', ', $p->bantuan_praktik) }}
                        @else
                            {{ $p->bantuan_praktik ?? '-' }}
                        @endif
                    </td>

                    <td>
                        @if(is_array($p->terapi_sokongan))
                            {{ implode(', ', $p->terapi_sokongan) }}
                        @else
                            {{ $p->terapi_sokongan ?? '-' }}
                        @endif
                    </td>

                    <td>@if(strtolower($p->jenis_agensi ?? '') == 'kerajaan')
                    ✅<br><small>({{ $p->agensi ?? '-' }})</small>@endif</td>
                    <td>@if(strtolower($p->jenis_agensi ?? '') == 'bukan kerajaan')
                    ✅<br><small>({{ $p->agensi ?? '-' }})</small>@endif</td>
                    <td>{{ $p->jumlah_kelulusan ? 'RM ' . number_format($p->jumlah_kelulusan, 2) : '-' }}</td>
                    <td>{{ $p->working_days !== null && $p->working_days <= 5 ? '✅' : '' }}</td>
                    <td>{{ $p->working_days !== null && $p->working_days > 5 ? '✅' : '' }}</td>
                    <td>{{ $p->catatan ?? '-' }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="13" class="no-data">Tiada rekod ditemui.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <a href="{{ route('redirect') }}" onclick="return confirmHome(event)" class="back-btn">⬅ Kembali ke Dashboard</a>

    <button id="scrollBottomBtn" title="Pergi ke bawah">⬇️</button>

    <script>
        function printKPI2() {
            const printContents = `
                <div style="text-align:center;">
                    <h2>Jabatan Kerja Sosial Perubatan</h2>
                    <h3>KPI 2 - Laporan Agensi Pemberi Bantuan</h3>
                    <p>Bulan: {{ \Carbon\Carbon::create()->month($bulan)->translatedFormat('F') }} {{ $tahun }}</p>
                </div>
                ${document.querySelector('table').outerHTML}
            `;

            const printWindow = window.open('', '', 'height=700,width=1000');
            printWindow.document.write('<html><head><title>Cetak KPI 2</title>');
            printWindow.document.write(`
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    h2, h3, p { text-align: center; margin: 0; }
                    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                    th, td { border: 1px solid #000; padding: 6px; text-align: center; font-size: 13px; }
                    th { background: #204d84; color: white; }
                </style>
            `);
            printWindow.document.write('</head><body>');
            printWindow.document.write(printContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }

        // Scroll button behavior
        document.getElementById("scrollBottomBtn").addEventListener("click", () => {
            window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
        });
        window.addEventListener("scroll", () => {
            const btn = document.getElementById("scrollBottomBtn");
            btn.style.display = (window.innerHeight + window.scrollY < document.body.scrollHeight - 200) ? "block" : "none";
        });
    </script>
</body>

</html>