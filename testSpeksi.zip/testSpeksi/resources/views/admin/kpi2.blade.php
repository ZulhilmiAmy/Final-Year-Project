<!DOCTYPE html>
<html lang="ms">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KPI 2 - Agensi Pemberi Bantuan</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: "Segoe UI", Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f5f6fa;
        }

        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            margin: 20px auto;
            max-width: 1200px;
        }

        .card-header {
            background: #204d84;
            color: white;
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .card-header h2 {
            margin: 0;
            font-size: 20px;
        }

        .card-body {
            padding: 25px;
            background: #fafafa;
        }

        .info {
            color: #555;
            margin-bottom: 25px;
        }

        .row {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 25px;
        }

        .stat-card {
            flex: 1 1 calc(33.333% - 20px);
            background: #e9f0ff;
            border-radius: 10px;
            text-align: center;
            padding: 20px;
            color: #204d84;
            font-weight: bold;
            box-shadow: 0 1px 5px rgba(0, 0, 0, 0.05);
        }

        .stat-card:nth-child(2) {
            background: #d5f5e3;
            color: #1b5e20;
        }

        .stat-card:nth-child(3) {
            background: #d0ebff;
            color: #01579b;
        }

        .stat-card h3 {
            margin: 10px 0 0;
            font-size: 28px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }

        table th,
        table td {
            border: 1px solid #ccc;
            padding: 8px 10px;
            text-align: center;
        }

        table th {
            background: #e3f2fd;
            color: #204d84;
            font-weight: bold;
        }

        table th small {
            color: #666;
            font-weight: normal;
        }

        .highlight {
            background: #e8f5e9;
            font-weight: bold;
        }

        .text-muted {
            color: #888;
        }

        .btn-back {
            display: inline-block;
            background: #777;
            color: white;
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            margin-top: 20px;
            transition: background 0.3s;
        }

        .btn-back:hover {
            background: #333;
        }

        @media (max-width: 768px) {
            table {
                font-size: 12px;
            }

            .stat-card {
                flex: 1 1 100%;
            }
        }
    </style>
</head>

<body>
    <div class="card">
        <div class="card-header">
            <h2><i class="fas fa-chart-line"></i> KPI 2 - Statistik Kes Rujukan ke Agensi Pemberi Bantuan</h2>
            <span>MSW KPI 2</span>
        </div>

        <div class="card-body">
            <p class="info"><i class="fas fa-info-circle"></i> Data menunjukkan tempoh masa antara
                <strong>Tarikh Dokumen Lengkap Diterima</strong> dan <strong>Tarikh Laporan Dihantar</strong>.
            </p>

            <!-- KPI Cards -->
            <div class="row">
                <div class="stat-card">
                    <div>JUMLAH KES</div>
                    <h3>{{ $totalCases }}</h3>
                </div>
                <div class="stat-card">
                    <div>DALAM TEMPOH ≤ 5 HARI</div>
                    <h3>{{ $within5Days }}</h3>
                </div>
                <div class="stat-card">
                    <div>% KECEKAPAN</div>
                    <h3>{{ $percentage }}%</h3>
                </div>
            </div>

            <!-- Jadual -->
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th rowspan="2">BIL</th>
                            <th rowspan="2">NAMA PESAKIT</th>
                            <th rowspan="2">NO FAIL PESAKIT</th>
                            <th rowspan="2">TARIKH INTERVENSI SOSIAL SELESAI<br><small>(Tarikh Dokumen Lengkap
                                    Diterima)</small></th>
                            <th rowspan="2">TARIKH KES RUJUKAN DIHANTAR<br><small>(Tarikh Permohonan)</small></th>
                            <th colspan="2">JENIS BANTUAN</th>
                            <th colspan="3">AGENSI PEMBERI BANTUAN</th>
                            <th colspan="2">TEMPOH MASA</th>
                            <th rowspan="2">CATATAN</th>
                        </tr>
                        <tr>
                            <th>BANTUAN PRAKTIK</th>
                            <th>BANTUAN TERAPI SOKONGAN</th>
                            <th>KERAJAAN</th>
                            <th>BUKAN KERAJAAN</th>
                            <th>JUMLAH BANTUAN (RM)</th>
                            <th>
                                < 5 HARI</th>
                            <th>> 5 HARI</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($patients as $index => $p)
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                <td>{{ $p->nama ?? '-' }}</td>
                                <td>{{ $p->no_fail ?? '-' }}</td>

                                <td>{{ $p->tarikh_dokumen_lengkap ? \Carbon\Carbon::parse($p->tarikh_dokumen_lengkap)->format('d/m/Y') : '-' }}
                                </td>
                                <td>{{ $p->tarikh_laporan ? \Carbon\Carbon::parse($p->tarikh_laporan)->format('d/m/Y') : '-' }}
                                </td>

                                <td>{{ is_array($p->bantuan_praktik) ? implode(', ', $p->bantuan_praktik) : ($p->bantuan_praktik ?? '-') }}
                                </td>
                                <td>{{ is_array($p->bantuan_terapi) ? implode(', ', $p->bantuan_terapi) : ($p->bantuan_terapi ?? '-') }}
                                </td>

                                <td></td> {{-- Kerajaan --}}
                                <td></td> {{-- Bukan kerajaan --}}
                                <td></td> {{-- Jumlah Bantuan --}}

                                <td>{{ $p->working_days !== null && $p->working_days <= 5 ? '✅' : '' }}</td>
                                <td>{{ $p->working_days !== null && $p->working_days > 5 ? '✅' : '' }}</td>

                                <td>{{ $p->catatan ?? '-' }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="13" class="text-muted">Tiada rekod ditemui.</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <a href="{{ route('admin.dashboard') }}" class="btn-back"><i class="fas fa-arrow-left"></i> Kembali</a>
        </div>
    </div>
</body>

</html>