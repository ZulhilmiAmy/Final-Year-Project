
<!DOCTYPE html>
<html lang="ms">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SPeKSi - Jumlah Kes <?php echo e(now()->year); ?></title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <link rel="stylesheet" href="<?php echo e(asset('css/totalCase.css')); ?>?v=<?php echo e(time()); ?>">
</head>

<body>

    <!-- 🔹 Header Banner -->
    <div class="header">
        <img src="https://raw.githubusercontent.com/ZulhilmiAmy/Final-Year-Project/main/Banner/Banner-SPeKSi.png"
            alt="Banner">
    </div>

    <!-- 🔹 Top Navigation -->
    <div class="top-bar">
        <div class="breadcrumbs">
            <a>Log Masuk</a> &gt;
            <?php if(Auth::user()->role === 'admin'): ?>
                <a href="<?php echo e(route('admin.home')); ?>">Halaman Utama</a>
            <?php else: ?>
                <a href="<?php echo e(route('home')); ?>">Halaman Utama</a>
            <?php endif; ?> &gt;
            <a>Jumlah Kes</a>
        </div>
    </div>

    <!-- 🔹 Content -->
    <div class="container">
        <h1>📊 Jumlah Kes <?php echo e(now()->year); ?></h1>

        <div class="summary-card">
            <div>Jumlah Kes Tahun <?php echo e(now()->year); ?></div>
            <div class="highlight"><?php echo e($totalCasesYear); ?></div>
        </div>

        <!-- Table -->
        <div class="data-card">
            <div class="card-header">Jumlah Kes Mengikut Bulan</div>
            <table class="custom-table">
                <thead>
                    <tr>
                        <th>Bulan</th>
                        <th>Jumlah Kes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $casesByMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $case): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php
                                $bulanMelayu = [
                                    1 => 'Januari',
                                    2 => 'Februari',
                                    3 => 'Mac',
                                    4 => 'April',
                                    5 => 'Mei',
                                    6 => 'Jun',
                                    7 => 'Julai',
                                    8 => 'Ogos',
                                    9 => 'September',
                                    10 => 'Oktober',
                                    11 => 'November',
                                    12 => 'Disember',
                                ];
                            ?>

                            <td><?php echo e($bulanMelayu[$case->month] ?? '-'); ?></td>
                            <td><?php echo e($case->total); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Chart -->
        <div class="data-card">
            <div class="card-header">Graf Kes Mengikut Bulan (<?php echo e(now()->year); ?>)</div>
            <canvas id="casesChart"></canvas>
        </div>

        
        <?php
            $dashboardRoute = Auth::check() && strtolower(Auth::user()->role) === 'admin'
                ? 'admin.dashboard'
                : 'home';
        ?>

        <a href="<?php echo e(route($dashboardRoute)); ?>" class="back-btn">⬅ Kembali ke Halaman Utama</a>
    </div>

    <script>
        const ctx = document.getElementById('casesChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($casesByMonth->pluck('month')->map(fn($m) => [
    1 => 'Januari',
    2 => 'Februari',
    3 => 'Mac',
    4 => 'April',
    5 => 'Mei',
    6 => 'Jun',
    7 => 'Julai',
    8 => 'Ogos',
    9 => 'September',
    10 => 'Oktober',
    11 => 'November',
    12 => 'Disember'
][$m] ?? '-')); ?>,
                datasets: [{
                    label: 'Jumlah Kes',
                    data: <?php echo json_encode($casesByMonth->pluck('total')); ?>,
                    backgroundColor: '#204d84'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: { stepSize: 1 }
                    }
                }
            }
        });
    </script>

    <style>
        /* Tambah gaya sama macam KPI1 */
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 18px;
            background: #204d84;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
        }

        .back-btn:hover {
            background: #2e6ab0;
        }
    </style>
</body>

</html><?php /**PATH C:\laragon\www\testSpeksi\resources\views/admin/totalCase.blade.php ENDPATH**/ ?>