<!doctype html>
<html lang="ms">
<head>
  <meta charset="utf-8">
  <title>Surat Temujanji Pesakit</title>
  <style>
    @page {
      size: A4;
      margin: 0.5cm 2.5cm 2.2cm 2.5cm;
    }

    body {
      font-family: "Times New Roman", serif;
      font-size: 11pt;
      line-height: 1.3;
      color: #000;
    }

    /* Header */
    .header-table {
      width: 100%;
      border-collapse: collapse;
    }

    .header-table td {
      vertical-align: top;
    }

    .header-table img {
      width: 90px;
      height: auto;
    }

    .hospital-info {
      font-size: 11pt;
      line-height: 1.25;
      padding-left: 8px;
      font-weight: bold;
    }

    .divider {
      border-top: 2px solid #000;
      margin: 5px 0 10px 0;
    }

    /* Nota atas */
    .top-note {
      width: 100%;
      position: relative;
      margin-bottom: 15px;
    }

    .note-left {
      font-style: italic;
      font-size: 11pt;
      display: inline-block;
    }

    .note-right {
      position: absolute;
      right: 0;
      top: 0;
      font-size: 11pt;
      line-height: 1.4;
      text-align: left;
    }

    .note-right table {
      border-collapse: collapse;
    }

    .note-right td {
      padding: 1px 4px;
    }

    .address {
      margin-top: 5px;
      margin-bottom: 10px;
      line-height: 1.3;
    }

    .content {
      text-align: justify;
    }

    .content p {
      margin: 0 0 10px 0;
    }

    .info-box {
      margin-left: 3cm;
      margin-top: 6px;
      margin-bottom: 10px;
      line-height: 1.3;
    }

    .footer {
      margin-top: 35px;
      font-size: 11pt;
    }

    .signature {
      margin-top: 50px;
    }

    .signature p {
      margin: 3px 0;
    }

    .sk {
      margin-top: 10px;
      line-height: 1.25;
    }
  </style>
</head>

<body>
  
  <table class="header-table">
    <tr>
      <td style="width: 90px;">
        <img src="<?php echo e(public_path('images/logo-kkm.png')); ?>" alt="Logo KKM">
      </td>
      <td class="hospital-info">
        JABATAN KERJA SOSIAL PERUBATAN,<br>
        HOSPITAL ENCHE’ BESAR HAJJAH KHALSOM<br>
        KM. 5, Jalan Kota Tinggi,<br>
        86000 Kluang<br>
        JOHOR DARUL TAKZIM
      </td>
    </tr>
  </table>

  
  <div class="divider"></div>

  
  <div class="top-note">
    <div class="note-left">
      Sila rujukkan bilangan surat ini apabila menjawab
    </div>

    <div class="note-right">
      <table>
        <tr>
          <td style="width: 75px;">Ruj. Tuan</td>
          <td style="width: 10px;">:</td>
          <td></td>
        </tr>
        <tr>
          <td>Ruj. Kami</td>
          <td>:</td>
          <td>HEBHK/JKSP/<?php echo e($patient->id ?? '24'); ?> ( )</td>
        </tr>
        <tr>
          <td>Tarikh</td>
          <td>:</td>
          <td><?php echo e($tarikhTemu ? $tarikhTemu->translatedFormat('F Y') : \Carbon\Carbon::now()->translatedFormat('F Y')); ?></td>
        </tr>
      </table>
    </div>
  </div>

  
  <div class="address">
    <?php echo e(strtoupper($patient->nama ?? '-')); ?><br><br><br><br><br><br>
    <?php echo $alamatFormatted; ?><br>
    <?php echo e($patient->poskod ?? ''); ?>, <?php echo e(strtoupper($patient->bandar ?? '')); ?><br>
    <?php echo e(strtoupper($patient->negeri ?? '')); ?>.
  </div>

  
  <div class="content">
    <p><strong>Tuan/Puan,</strong></p>
    <p><strong>PER: TEMUJANJI PESAKIT</strong></p>

    <p>Saya dengan hormatnya merujuk perkara di atas.</p>

    <ol start="2">
      <li>
        Sukacita dimaklumkan bahawa pihak kami memohon kerjasama pihak tuan/puan untuk hadir di
        Jabatan Kerja Sosial Perubatan, Hospital Enche’ Besar Hajjah Khalsom, Kluang bagi urusan
        bantuan praktik/terapi sokongan seperti berikut:
      </li>
    </ol>

    <div class="info-box">
      <strong>Tarikh</strong> : <?php echo e($tarikhTemuFormatted ?? '-'); ?> (<?php echo e($hariTemu ?? '-'); ?>)<br>
      <strong>Masa</strong> : <?php echo e($patient->masa_temu ?? '-'); ?><br>
      <strong>Tempat</strong> : Jabatan Kerja Sosial Perubatan, Aras 3<br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Hospital Enche’ Besar Hajjah Khalsom, Kluang
    </div>

    <ol start="3">
      <li>
        Sila bawa dokumen sesalinan kad pengenalan dan salinan laporan polis pada tarikh
        temujanji tersebut. Sekiranya ada pertanyaan, sila hubungi
        <?php echo e($patient->pegawai_kes ?? 'Pegawai Kes'); ?> di talian 07-7787000 sambungan 2363.
        Kerjasama tuan/puan dalam perkara ini amat dihargai dan didahului dengan ucapan
        terima kasih.
      </li>
    </ol>

    <div class="footer">
      <p><strong>“MALAYSIA MADANI”</strong><br>
        <strong>“BERKHIDMAT UNTUK NEGARA”</strong></p>
    </div>

    <div class="signature">
      <p>Saya yang menjalankan amanah,</p>
      <br><br><br>
      <p>______________________________</p>
      <p>(<strong><?php echo e($patient->pegawai_kes ?? 'RAIMAH BINTI ISMAIL'); ?></strong>)</p>
      <p>Ketua Jabatan</p>
      <p>Jabatan Kerja Sosial Perubatan</p>
      <p>b.p. Pengarah Hospital Enche’ Besar Hajjah Khalsom, Kluang</p>
    </div>

    <div class="sk">
      <p><strong>s.k :</strong></p>
      <p>1. Pengarah Hospital</p>
      <p>2. Fail Pesakit <?php echo e($patient->no_fail ?? '---'); ?></p>
    </div>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\testSpeksi\resources\views/letters/appointment.blade.php ENDPATH**/ ?>