<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="utf-8">
    <title>KPI 2 - Kes Dirujuk ke Agensi</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/homeAdmin.css')); ?>?v=<?php echo e(time()); ?>">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        th, td {
            border: 1px solid #000;
            padding: 6px;
            text-align: center;
            font-size: 13px;
        }
        th {
            background: #204d84;
            color: white;
        }
        .editable {
            background-color: #fff8e1;
            cursor: pointer;
        }
        h2 {
            text-align: center;
            color: #204d84;
        }
    </style>
</head>
<body>
    <div class="header">
        <img src="https://raw.githubusercontent.com/ZulhilmiAmy/Final-Year-Project/main/Banner/Banner-SPeKSi.png" alt="Banner">
    </div>

    <div class="container">
        <div class="title">📊 KPI 2: Kes Dirujuk ke Agensi Dalam 5 Hari Bekerja</div>

        <div style="background:#f0f6fa; padding:10px; border-radius:10px; border:2px solid #204d84; text-align:center;">
            <h3>Jumlah Kes Dirujuk ke Agensi: <strong><?php echo e($totalCases); ?></strong></h3>
            <h3>Jumlah Kes Dirujuk Dalam ≤ 5 Hari Bekerja: <strong><?php echo e($within5Days); ?></strong></h3>
            <h2>KPI 2 = <?php echo e($percentage); ?>%</h2>
        </div>

        <table style="margin-top:20px;">
            <thead>
                <tr>
                    <th>BIL</th>
                    <th>NAMA PESAKIT</th>
                    <th>TARIKH LAPORAN</th>
                    <th>TARIKH KELULUSAN</th>
                    <th>BIL. HARI BEKERJA</th>
                    <th>AGENSI PEMBERI BANTUAN</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($p->nama ?? '-'); ?></td>
                        <td><?php echo e($p->tarikh_laporan ? \Carbon\Carbon::parse($p->tarikh_laporan)->format('d-m-Y') : '-'); ?></td>
                        <td><?php echo e($p->tarikh_kelulusan ? \Carbon\Carbon::parse($p->tarikh_kelulusan)->format('d-m-Y') : '-'); ?></td>
                        <td><?php echo e($p->working_days ?? '-'); ?></td>
                        <td contenteditable="true" class="editable" data-id="<?php echo e($p->id); ?>"><?php echo e($p->agensi ?? '-'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6">Tiada rekod ditemui.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div style="margin-top:25px; text-align:center;">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn-register">← Kembali ke Dashboard</a>
        </div>
    </div>

    <script>
        document.querySelectorAll('.editable').forEach(cell => {
            cell.addEventListener('blur', function() {
                const id = this.dataset.id;
                const agensi = this.textContent.trim();

                fetch('<?php echo e(route("admin.kpi2.update")); ?>', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ id, agensi })
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        this.style.backgroundColor = '#d4edda';
                        setTimeout(() => this.style.backgroundColor = '#fff8e1', 1000);
                    }
                })
                .catch(err => console.error(err));
            });
        });
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\testSpeksi\resources\views/admin/kpi2.blade.php ENDPATH**/ ?>