<!DOCTYPE html>
<html lang="ms">

<head>
    <meta charset="UTF-8">
    <title>KPI 1 FORM</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f7fa;
            margin: 20px;
        }

        .header {
            color: #fff;
            padding: 0;
            text-align: center;
            margin: -20px -20px 20px -20px;
        }

        .header img {
            width: 100%;
            max-height: 180px;
            object-fit: cover;
        }

        .top-bar {
            display: flex;
            background: #f8f9fa;
            padding: 8px 20px;
            border-bottom: 2px solid #204d84;
            font-size: 14px;
        }

        .breadcrumbs a {
            color: #204d84;
            text-decoration: none;
            font-weight: 500;
        }

        .breadcrumbs a:hover {
            text-decoration: underline;
        }

        .breadcrumbs .separator {
            color: #204d84;
            margin: 0 4px;
        }

        h1 {
            text-align: center;
            background: #204d84;
            color: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            border: 1px solid #000;
            padding: 6px;
            text-align: center;
            font-size: 14px;
        }

        th {
            background: #204d84;
            color: white;
        }

        td:nth-child(3) {
            text-align: left;
            /* nama pesakit align kiri */
        }

        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 18px;
            background: #204d84;
            color: white;
            border-radius: 6px;
            text-decoration: none;
        }

        .no-data {
            text-align: center;
            color: #888;
            padding: 12px;
        }

        form select {
            padding: 6px 10px;
            border-radius: 6px;
            border: 1px solid #204d84;
            font-size: 14px;
            margin-left: 8px;
        }

        form label {
            font-weight: bold;
            color: #204d84;
        }

        /* Butang Scroll ke Bawah */
        #scrollBottomBtn {
            position: fixed;
            right: 25px;
            bottom: 25px;
            background-color: #204d84;
            color: white;
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            font-size: 22px;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            display: none;
            z-index: 9999;
            transition: transform 0.2s ease, background-color 0.3s ease;
        }

        #scrollBottomBtn:hover {
            background-color: #2e6ab0;
            transform: scale(1.1);
        }
    </style>
</head>

<body>
    <div class="header">
        <img src="https://raw.githubusercontent.com/ZulhilmiAmy/Final-Year-Project/main/Banner/Banner-SPeKSi.png"
            alt="Banner">
        <div class="top-bar">
            <div class="breadcrumbs">
                <a>Log Masuk</a>
                <span class="separator">&gt;</span>
                <a href="<?php echo e(route('redirect')); ?>">Halaman Utama</a>
                <span class="separator">&gt;</span>
                <a>KPI 1</a>
            </div>
        </div>
    </div>

    <h1>KPI 1 FORM</h1>
    <div style="text-align:center; margin-bottom:20px;">
        <form method="GET" action="<?php echo e(route('admin.kpi1')); ?>" style="display:inline-block; margin-right:15px;">
            <label for="bulan">Pilih Bulan:</label>
            <select name="bulan" id="bulan" onchange="this.form.submit()">
                <?php for($m = 1; $m <= 12; $m++): ?>
                    <option value="<?php echo e($m); ?>" <?php echo e($m == $bulan ? 'selected' : ''); ?>>
                        <?php echo e(\Carbon\Carbon::create()->month($m)->translatedFormat('F')); ?>

                    </option>
                <?php endfor; ?>
            </select>

            <select name="tahun" id="tahun" onchange="this.form.submit()">
                <?php $__currentLoopData = $availableYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($y); ?>" <?php echo e($y == $tahun ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </form>

        <!-- 🖨️ Butang Print -->
        <button onclick="printKPI1()" style="
            background: #204d84;
            color: white;
            border: none;
            padding: 8px 14px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        ">
            🖨️ Cetak Laporan
        </button>
    </div>



    <table>
        <thead>
            <tr>
                <th>BIL</th>
                <th>NO. JKSP</th>
                <th>NAMA PESAKIT</th>
                <th>TARIKH TERIMA RUJUKAN</th>
                <th>TARIKH INTERVENSI AWAL<br>(TARIKH TINDAKBALAS AWAL)</th>
                <th>PENCAPAIAN<br>1-2 HARI<br>(√)</th>
                <th>PENCAPAIAN<br>> 2 HARI<br>(√)</th>
                <th>CATATAN</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    // Kira hari bekerja antara dua tarikh
                    if ($p->tarikh_tindakbalas_awal && $p->tarikh_rujukan) {
                        $start = \Carbon\Carbon::parse($p->tarikh_rujukan);
                        $end = \Carbon\Carbon::parse($p->tarikh_tindakbalas_awal);
                        $workingDays = 0;

                        for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                            if ($date->isWeekday()) {
                                $workingDays++;
                            }
                        }
                    } else {
                        $workingDays = null;
                    }
                ?>

                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($p->no_fail ?? '-'); ?></td>
                    <td><?php echo e($p->nama ?? '-'); ?></td>
                    <td><?php echo e($p->tarikh_rujukan ? \Carbon\Carbon::parse($p->tarikh_rujukan)->format('d-m-Y') : '-'); ?></td>
                    <td><?php echo e($p->tarikh_tindakbalas_awal ? \Carbon\Carbon::parse($p->tarikh_tindakbalas_awal)->format('d-m-Y') : '-'); ?>

                    </td>

                    <td><?php if($workingDays !== null && $workingDays <= 2): ?> ✓ <?php endif; ?></td>
                    <td><?php if($workingDays !== null && $workingDays > 2): ?> ✓ <?php endif; ?></td>
                    <td>-</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="no-data">Tiada rekod ditemui.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php
        $dashboardRoute = Auth::check() && strtolower(Auth::user()->role) === 'admin'
            ? 'admin.dashboard'
            : 'home'; // untuk user
    ?>

    <a href="<?php echo e(route($dashboardRoute)); ?>" class="back-btn">⬅ Kembali ke Dashboard</a>
    </a>
    <!-- Butang Scroll ke Bawah -->
    <button id="scrollBottomBtn" title="Pergi ke bawah">
        ⬇️
    </button>
    <script>
        function printKPI1() {
            // Simpan bahagian yang nak dicetak (tajuk + jadual)
            const printContents = `
            <div style="text-align:center;">
                <h2>Jabatan Kerja Sosial Perubatan</h2>
                <h3>KPI 1 - Kes yang diberi tindak balas dalam masa 1-2 hari</h3>
                <p>Bulan: <?php echo e(\Carbon\Carbon::create()->month($bulan)->translatedFormat('F')); ?> <?php echo e($tahun); ?></p>
            </div>
            ${document.querySelector('table').outerHTML}
        `;

            const printWindow = window.open('', '', 'height=700,width=1000');
            printWindow.document.write('<html><head><title>Cetak KPI 1</title>');
            printWindow.document.write(`
            <style>
                body { font-family: Arial, sans-serif; padding: 20px; }
                h2, h3, p { text-align: center; margin: 0; }
                table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                th, td { border: 1px solid #000; padding: 6px; text-align: center; font-size: 13px; }
                th { background: #204d84; color: white; }
                td:nth-child(3) { text-align: left; }
            </style>
        `);
            printWindow.document.write('</head><body>');
            printWindow.document.write(printContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();
        }

        // Bila klik, scroll ke bawah
        document.getElementById("scrollBottomBtn").addEventListener("click", function () {
            window.scrollTo({
                top: document.body.scrollHeight,
                behavior: "smooth"
            });
        });

        // Tunjuk butang bila user scroll ke atas sikit
        window.addEventListener("scroll", function () {
            const btn = document.getElementById("scrollBottomBtn");
            if (window.innerHeight + window.scrollY < document.body.scrollHeight - 200) {
                btn.style.display = "block";
            } else {
                btn.style.display = "none";
            }
        });
    </script>

</body>

</html><?php /**PATH C:\laragon\www\testSpeksi\resources\views/admin/kpi1.blade.php ENDPATH**/ ?>