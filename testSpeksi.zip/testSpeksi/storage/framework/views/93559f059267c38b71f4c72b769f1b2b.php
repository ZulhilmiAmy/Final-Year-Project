<!DOCTYPE html>
<html lang="ms">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengguna Baru</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('css/registerUser.css')); ?>?v=<?php echo e(time()); ?>">
</head>

<body>

    <div class="header">
        <img src="https://raw.githubusercontent.com/ZulhilmiAmy/Final-Year-Project/main/Banner/Banner-SPeKSi.png"
            alt="Banner">
        <div class="top-bar">
            <div class="breadcrumbs">
                <a>Log Masuk</a>
                <span class="separator">&gt;</span>
                <a href="<?php echo e(route('redirect')); ?>">Halaman Utama</a>
                <span class="separator">&gt;</span>
                <a>Daftar Pengguna Baru</a>
            </div>
        </div>
    </div>

    <div class="container">
        <h2><i class="fas fa-user-plus"></i> Daftar Pengguna Baru</h2>

        <form method="POST" action="<?php echo e(route('admin.registerUser.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="name">Nama Penuh</label>
                <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
            </div>

            <div class="form-group">
                <label for="username">Email / ID Pengguna</label>
                <input type="email" id="username" name="username" value="<?php echo e(old('username')); ?>" required>
            </div>

            <div class="form-group">
                <label for="password">Kata Laluan</label>
                <input type="password" id="password" name="password" required>
            </div>

            <div class="form-group">
                <label for="password_confirmation">Sahkan Kata Laluan</label>
                <input type="password" id="password_confirmation" name="password_confirmation" required>
            </div>

            <div class="form-group">
                <label for="role">Peranan</label>
                <select name="role" id="role" required>
                    <option value="user">Pengguna Biasa</option>
                    <option value="admin">Admin</option>
                </select>
            </div>

            <button type="submit" class="btn">Daftar</button>
        </form>

        <a href="<?php echo e(route('admin.dashboard')); ?>" class="back-btn">← Kembali ke Dashboard</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        document.querySelector("form").addEventListener("submit", function (e) {
            e.preventDefault();

            const form = this;
            const formData = new FormData(form);

            Swal.fire({
                title: 'Mendaftar Pengguna...',
                text: 'Sila tunggu sebentar',
                allowOutsideClick: false,
                didOpen: () => Swal.showLoading()
            });

            fetch(form.action, {
                method: 'POST',
                body: formData,
                headers: { 'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' }
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            title: '✅ Pendaftaran Berjaya!',
                            html: `
                    <p style="font-size: 16px;">Pengguna <strong>${form.name.value}</strong> telah didaftarkan.</p>
                `,
                            icon: 'success',
                            showCancelButton: true,
                            confirmButtonText: '🏠 Kembali ke Halaman Utama',
                            cancelButtonText: '➕ Daftar Pengguna Lain',
                            confirmButtonColor: '#204d84',
                            cancelButtonColor: '#28a745'
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location.href = "<?php echo e(route('admin.dashboard')); ?>";
                            } else {
                                form.reset();
                            }
                        });
                    } else {
                        Swal.fire({
                            title: '❌ Ralat!',
                            text: 'Pendaftaran gagal. Sila semak maklumat dan cuba lagi.',
                            icon: 'error'
                        });
                    }
                })
                .catch(error => {
                    console.error(error);
                    Swal.fire({
                        title: '❌ Ralat Server!',
                        text: 'Terdapat masalah pada pelayan. Cuba lagi nanti.',
                        icon: 'error'
                    });
                });
        });
    </script>
</body>

</html><?php /**PATH C:\laragon\www\testSpeksi\resources\views/admin/registerUser.blade.php ENDPATH**/ ?>