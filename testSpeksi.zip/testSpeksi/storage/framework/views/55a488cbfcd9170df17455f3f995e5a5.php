
<!doctype html>
<html lang="ms">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Butiran Pesakit — <?php echo e($patient->nama ?? '-'); ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #eef2f7;
      margin: 0;
      padding: 20px;
    }

    .header {
      color: #fff;
      padding: 0;
      text-align: center;
      margin: -20px -20px 20px -20px;
    }

    .header img {
      width: 100%;
      max-height: 180px;
      object-fit: cover;
    }

    .top-bar {
      display: flex;
      background: #f8f9fa;
      padding: 8px 20px;
      border-bottom: 2px solid #204d84;
      font-size: 14px;
    }

    .breadcrumbs a {
      color: #204d84;
      text-decoration: none;
      font-weight: 500;
    }

    .breadcrumbs a:hover {
      text-decoration: underline;
    }

    .breadcrumbs .separator {
      color: #204d84;
      margin: 0 4px;
    }

    .container {
      max-width: 1000px;
      margin: 20px auto;
      padding: 25px;
      background: #fdfdfd;
      border-radius: 12px;
      border-top: 6px solid #204d84;
      box-shadow: 0 6px 18px rgba(0, 0, 0, 0.1);
    }

    h1 {
      color: #204d84;
      margin: 0 0 20px 0;
      text-align: center;
      font-size: 26px;
    }

    .section-card {
      margin-bottom: 25px;
      padding: 18px 20px;
      border: 1px solid #e0e6ed;
      border-radius: 10px;
      background: #fafcff;
    }

    .section-card h2 {
      margin-top: 0;
      margin-bottom: 15px;
      font-size: 18px;
      color: #204d84;
      border-left: 5px solid #50a7c2;
      padding-left: 10px;
    }

    .form-group {
      margin: 12px 0;
    }

    label {
      font-weight: bold;
      color: #333;
      display: block;
      margin-bottom: 4px;
    }

    .static-field {
      display: inline-block;
      border: 1px dashed #ccc;
      border-radius: 4px;
      padding: 6px 10px;
      min-width: 200px;
      background: #f5f8fb;
    }

    .static-field.wide-field {
      min-width: 350px;
    }

    /* Highlight untuk field kosong */
    .static-field.highlight {
      background-color: #ffcccc;
      border-color: #ff0000;
      color: #800000;
    }

    .action-buttons {
      display: flex;
      gap: 10px;
      justify-content: flex-end;
      margin-top: 25px;
    }

    .action-button {
      padding: 8px 14px;
      border-radius: 6px;
      font-size: 14px;
      cursor: pointer;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: background 0.2s ease;
      color: #fff;
    }

    .action-button.back {
      background: #6c757d;
    }

    .action-button.print {
      background: #ff9800;
    }

    .action-button:hover {
      opacity: 0.9;
    }

    .static-field.highlight {
      border: 2px solid red !important;
      background-color: #ffeaea !important;
      color: #000;
    }

    /* Butang Scroll ke Bawah */
    #scrollBottomBtn {
      position: fixed;
      right: 25px;
      bottom: 25px;
      background-color: #204d84;
      color: white;
      border: none;
      border-radius: 50%;
      width: 50px;
      height: 50px;
      font-size: 22px;
      cursor: pointer;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
      display: none;
      z-index: 9999;
      transition: transform 0.2s ease, background-color 0.3s ease;
    }

    #scrollBottomBtn:hover {
      background-color: #2e6ab0;
      transform: scale(1.1);
    }
  </style>
</head>

<body>
  <div class="header">
    <img src="https://raw.githubusercontent.com/ZulhilmiAmy/Final-Year-Project/main/Banner/Banner-SPeKSi.png"
      alt="Banner">
    <div class="top-bar">
      <div class="breadcrumbs">
        <a href="<?php echo e(route('login.custom')); ?>">Log Masuk</a>
        <span class="separator">&gt;</span>
        <a href="<?php echo e(route('redirect')); ?>">Halaman Utama</a>
        <span class="separator">&gt;</span>
        <a href="<?php echo e(route('patients.history', ['no_kp' => $patient->no_kp])); ?>">Sejarah Pesakit</a>
        <span class="separator">&gt;</span>
        <a>Butiran Pesakit</a>
      </div>
    </div>
  </div>

  <div class="container">
    <h1>Butiran Pesakit</h1>

    <?php
      use Carbon\Carbon;
      function fmtDate($d)
      {
        return $d ? Carbon::parse($d)->format('d-m-Y') : '-';
      }

      // Dapatkan nilai global pesakit (kita guna 'global' supaya dua field boleh saling tahu keadaan satu sama lain)
      $GLOBALS['bantuan_praktik_val'] = $patient->bantuan_praktik;
      $GLOBALS['terapi_sokongan_val'] = $patient->terapi_sokongan;

      function showGroup($val)
      {
        if (!$val)
          return '-';
        if (is_array($val))
          return implode(', ', $val);
        if (is_string($val) && (substr($val, 0, 1) == '[' || substr($val, 0, 1) == '{')) {
          $arr = json_decode($val, true);
          return is_array($arr) ? implode(', ', $arr) : $val;
        }
        return (string) $val;
      }

      // Fungsi highlight dinamik yang betul
      function highlight($value, $type = null)
      {
        // Untuk bantuan & terapi — highlight bila dua-dua kosong
        if ($type === 'bantuan_terapi') {
          $bantuan = $GLOBALS['bantuan_praktik_val'];
          $terapi = $GLOBALS['terapi_sokongan_val'];
          return (empty($bantuan) && empty($terapi)) ? 'highlight' : '';
        }

        // Untuk field biasa
        return empty($value) ? 'highlight' : '';
      }

    ?>

    <div class="section-card">
      <h2>1. Maklumat Peribadi</h2>
      <div class="form-group"><label>Tarikh Rujukan Diterima</label><span
          class="static-field <?php echo e(highlight($patient->tarikh_rujukan)); ?>"><?php echo e(fmtDate($patient->tarikh_rujukan)); ?></span>
      </div>
      <div class="form-group"><label>Tarikh Tindakblaas Awal</label><span
          class="static-field <?php echo e(highlight($patient->tarikh_tindakbalas_awal)); ?>"><?php echo e(fmtDate($patient->tarikh_tindakbalas_awal)); ?></span>
      </div>
      <div class="form-group"><label>Nama</label><span
          class="static-field <?php echo e(highlight($patient->nama)); ?>"><?php echo e($patient->nama ?? '-'); ?></span></div>
      <div class="form-group"><label>No. KP</label><span
          class="static-field <?php echo e(highlight($patient->no_kp)); ?>"><?php echo e($patient->no_kp ?? '-'); ?></span></div>
      <div class="form-group"><label>Tarikh Lahir</label><span
          class="static-field <?php echo e(highlight($patient->tarikh_lahir)); ?>"><?php echo e(fmtDate($patient->tarikh_lahir)); ?></span>
      </div>
      <div class="form-group"><label>Umur</label><span
          class="static-field <?php echo e(highlight($patient->umur)); ?>"><?php echo e($patient->umur ?? '-'); ?></span></div>
      <div class="form-group"><label>Jantina</label><span
          class="static-field <?php echo e(highlight($patient->jantina)); ?>"><?php echo e($patient->jantina ?? '-'); ?></span></div>
      <div class="form-group"><label>Agama</label><span
          class="static-field <?php echo e(highlight($patient->agama)); ?>"><?php echo e($patient->agama ?? '-'); ?></span></div>
      <div class="form-group"><label>Bangsa</label><span
          class="static-field <?php echo e(highlight($patient->bangsa)); ?>"><?php echo e($patient->bangsa ?? '-'); ?></span></div>
      <div class="form-group">
        <label>Alamat</label>
        <span class="static-field wide-field <?php echo e(highlight($patient->alamat)); ?>">
          <?php echo e($patient->alamat ?? '-'); ?>

          <?php if($patient->poskod || $patient->bandar || $patient->negeri): ?>
            <?php echo e(', ' . ($patient->poskod ?? '')); ?>

            <?php echo e($patient->bandar ? ', ' . $patient->bandar : ''); ?>

            <?php echo e($patient->negeri ? ', ' . strtoupper($patient->negeri) : ''); ?>

          <?php endif; ?>
        </span>
      </div>
      <div class="form-group"><label>No. Tel.</label><span
          class="static-field <?php echo e(highlight($patient->no_tel)); ?>"><?php echo e($patient->no_tel ?? '-'); ?></span></div>
      <div class="form-group"><label>Tarikh Masuk Wad</label><span
          class="static-field <?php echo e(highlight($patient->tarikh_masuk_wad)); ?>"><?php echo e(fmtDate($patient->tarikh_masuk_wad)); ?></span>
      </div>
      <div class="form-group"><label>Tarikh Dijangka Discaj</label><span
          class="static-field <?php echo e(highlight($patient->tarikh_discaj)); ?>"><?php echo e(fmtDate($patient->tarikh_discaj)); ?></span>
      </div>
      <div class="form-group"><label>Diagnosa</label><span
          class="static-field <?php echo e(highlight($patient->diagnosa)); ?>"><?php echo e($patient->diagnosa ?? '-'); ?></span></div>
      <div class="form-group"><label>Prognosis</label><span
          class="static-field <?php echo e(highlight($patient->prognosis)); ?>"><?php echo e($patient->prognosis ?? '-'); ?></span></div>
      <div class="form-group"><label>Mobiliti Pesakit</label><span
          class="static-field <?php echo e(highlight($patient->mobiliti)); ?>"><?php echo e($patient->mobiliti ?? '-'); ?></span></div>




    </div>

    <div class="section-card">
      <h2>2. Tujuan Rujukan</h2>
      <div class="form-group"><label>Bantuan Praktik</label><span
          class="static-field <?php echo e(highlight($patient->bantuan_praktik, 'bantuan_terapi')); ?>"><?php echo e(showGroup($patient->bantuan_praktik)); ?></span>
      </div>
      <div class="form-group"><label>Terapi Sokongan</label><span
          class="static-field <?php echo e(highlight($patient->terapi_sokongan, 'bantuan_terapi')); ?>"><?php echo e(showGroup($patient->terapi_sokongan)); ?></span>
      </div>

    </div>

    <div class="section-card">
      <h2>3. Kategori Kes</h2>
      <div class="form-group"><label>Kategori</label><span
          class="static-field <?php echo e(highlight($patient->kategori_kes)); ?>"><?php echo e(showGroup($patient->kategori_kes)); ?></span>
      </div>
    </div>

    <div class="section-card">
      <h2>4. Maklumat Perujuk</h2>
      <div class="form-group"><label>Nama Perujuk</label><span
          class="static-field <?php echo e(highlight($patient->nama_perujuk)); ?>"><?php echo e($patient->nama_perujuk ?? '-'); ?></span></div>
      <div class="form-group"><label>Disiplin</label><span
          class="static-field <?php echo e(highlight($patient->disiplin)); ?>"><?php echo e($patient->disiplin ?? '-'); ?></span></div>
      <div class="form-group"><label>Punca Rujukan</label><span
          class="static-field <?php echo e(highlight($patient->wad_rujuk)); ?>"><?php echo e($patient->wad_rujuk ?? '-'); ?></span></div>
      <div class="form-group"><label>Diagnosis</label><span
          class="static-field <?php echo e(highlight($patient->diagnosis_rujuk)); ?>"><?php echo e($patient->diagnosis_rujuk ?? '-'); ?></span>
      </div>
    </div>

    <?php
      $isAdmin = auth()->user()->role == 'admin';
    ?>

    <div class="section-card">
      <h2>5. Rujukan ke Agensi</h2>

      <div class="form-group">
        <label>Jenis Agensi</label>
        <span class="static-field <?php echo e(highlight($patient->jenis_agensi)); ?>">
          <?php echo e($patient->jenis_agensi ?? '-'); ?>

        </span>
      </div>

      <div class="form-group">
        <label>Nama Agensi</label>
        <span class="static-field <?php echo e(highlight($patient->agensi)); ?>"><?php echo e($patient->agensi ?? '-'); ?></span>
      </div>

      <div class="form-group">
        <label>Nama Pembekal</label>
        <span class="static-field <?php echo e(highlight($patient->pembekal)); ?>"><?php echo e($patient->pembekal ?? '-'); ?></span>
      </div>

      <div class="form-group">
        <label>Tarikh Laporan Dihantar</label>
        <span
          class="static-field <?php echo e(highlight($patient->tarikh_laporan)); ?>"><?php echo e(fmtDate($patient->tarikh_laporan)); ?></span>
      </div>

      <div class="form-group">
        <label>Tarikh Dokumen Lengkap Diterima</label>
        <span
          class="static-field <?php echo e(highlight($patient->tarikh_dokumen_lengkap)); ?>"><?php echo e(fmtDate($patient->tarikh_dokumen_lengkap)); ?></span>
      </div>

      <div class="form-group">
        <label>Item Dipohon</label>
        <span class="static-field <?php echo e(highlight($patient->item_dipohon)); ?>"><?php echo e($patient->item_dipohon ?? '-'); ?></span>
      </div>

      <div class="form-group">
        <label>Tarikh Kelulusan</label>
        <span
          class="static-field <?php echo e(highlight($patient->tarikh_kelulusan)); ?>"><?php echo e(fmtDate($patient->tarikh_kelulusan)); ?></span>
      </div>

      <div class="form-group">
        <label>Tanggungan Pesakit (RM)</label>
        <span class="static-field <?php echo e(highlight($patient->tanggungan)); ?>"><?php echo e($patient->tanggungan ?? '-'); ?></span>
      </div>

      <div class="form-group">
        <label>Jumlah Dipohon (RM)</label>
        <span
          class="static-field <?php echo e(highlight($patient->jumlah_dipohon)); ?>"><?php echo e($patient->jumlah_dipohon ?? '-'); ?></span>
      </div>

      <div class="form-group">
        <label>Jumlah Kelulusan (RM)</label>
        <span
          class="static-field <?php echo e(highlight($patient->jumlah_kelulusan)); ?>"><?php echo e($patient->jumlah_kelulusan ?? '-'); ?></span>
      </div>

      <div class="form-group">
        <label>Tarikh Tuntut</label>
        <span
          class="static-field <?php echo e(highlight($patient->tarikh_tuntut)); ?>"><?php echo e(fmtDate($patient->tarikh_tuntut)); ?></span>
      </div>

      <div class="form-group">
        <label>Dokumen Sokongan</label>
        <?php if($patient->dokumen_sokongan): ?>
          <a href="<?php echo e(asset('storage/' . $patient->dokumen_sokongan)); ?>" target="_blank" class="static-field">Lihat
            Dokumen</a>
        <?php else: ?>
          <span class="static-field">Tiada dokumen</span>
        <?php endif; ?>
      </div>
    </div>




    <div class="section-card">
      <h2>6. Temu Janji</h2>
      <div class="form-group"><label>Pegawai Kes</label><span
          class="static-field <?php echo e(highlight($patient->pegawai_kes)); ?>"><?php echo e($patient->pegawai_kes ?? '-'); ?></span></div>
      <div class="form-group"><label>Tarikh Temu Janji</label><span
          class="static-field <?php echo e(highlight($patient->tarikh_temu)); ?>"><?php echo e(fmtDate($patient->tarikh_temu)); ?></span></div>
      <div class="form-group"><label>Masa Temu Janji</label><span
          class="static-field <?php echo e(highlight($patient->masa_temu)); ?>"><?php echo e($patient->masa_temu ? \Carbon\Carbon::parse($patient->masa_temu)->format('h:i A') : '-'); ?></span>
      </div>
      <div class="form-group"><label>Catatan Temu Janji</label><span
          class="static-field wide-field <?php echo e(highlight($patient->catatan_temu)); ?>"><?php echo e($patient->catatan_temu ?? '-'); ?></span>
      </div>
      <div class="form-group"><label>No. Rujukan Fail</label><span
          class="static-field <?php echo e(highlight($patient->no_fail)); ?>"><?php echo e($patient->no_fail ?? '-'); ?></span></div>

    </div>

    <div class="action-buttons">
      <a class="action-button back" href="<?php echo e(route('patients.history', ['no_kp' => $patient->no_kp])); ?>"><i
          class="fas fa-arrow-left"></i> Kembali</a>
      <a class="action-button print" href="<?php echo e(route('patients.letter', $patient->id)); ?>" target="_blank"><i
          class="fas fa-print"></i> Cetak Surat</a>
    </div>
  </div>

  <!-- Butang Scroll ke Bawah -->
  <button id="scrollBottomBtn" title="Pergi ke bawah">
    ⬇️
  </button>
</body>

<script>
  function confirmNav(e, msg) {
    e.preventDefault();
    if (confirm(msg)) {
      window.location.href = e.target.href;
    }
    return false;
  }

  // Bila klik, scroll ke bawah
  document.getElementById("scrollBottomBtn").addEventListener("click", function () {
    window.scrollTo({
      top: document.body.scrollHeight,
      behavior: "smooth"
    });
  });

  // Tunjuk butang bila user scroll ke atas sikit
  window.addEventListener("scroll", function () {
    const btn = document.getElementById("scrollBottomBtn");
    if (window.innerHeight + window.scrollY < document.body.scrollHeight - 200) {
      btn.style.display = "block";
    } else {
      btn.style.display = "none";
    }
  });
</script>

</html><?php /**PATH C:\laragon\www\testSpeksi\resources\views/patients/show.blade.php ENDPATH**/ ?>