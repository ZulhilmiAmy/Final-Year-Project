let captchaCode = "";

function generateCaptcha() {
    const canvas = document.getElementById("captchaCanvas");
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    captchaCode = "";
    for (let i = 0; i < 5; i++) {
        captchaCode += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    // Background dengan noise
    ctx.fillStyle = "#f9f9f9";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    // Tambahkan noise titik-titik
    for (let i = 0; i < 100; i++) {
        ctx.fillStyle = `rgba(0, 0, 0, ${Math.random() * 0.2})`;
        ctx.beginPath();
        ctx.arc(
            Math.random() * canvas.width,
            Math.random() * canvas.height,
            Math.random() * 2,
            0,
            Math.PI * 2
        );
        ctx.fill();
    }

    // Tambahkan garis-garis gangguan
    for (let i = 0; i < 8; i++) {
        ctx.strokeStyle = `rgba(0, 0, 0, ${Math.random() * 0.3})`;
        ctx.beginPath();
        ctx.moveTo(Math.random() * canvas.width, Math.random() * canvas.height);
        ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
        ctx.stroke();
    }

    // Tulis teks captcha dengan efek senget dan variasi
    const textY = canvas.height / 2 + 5;
    for (let i = 0; i < captchaCode.length; i++) {
        const char = captchaCode[i];
        const offsetX = 20 + i * 20;
        const rotation = Math.random() * 0.4 - 0.2; // Rotasi antara -0.2 hingga 0.2 radian
        const skew = Math.random() * 0.3 - 0.15; // Senget antara -0.15 hingga 0.15
        
        ctx.save();
        ctx.translate(offsetX, textY);
        ctx.rotate(rotation);
        ctx.transform(1, skew, 0, 1, 0, 0);
        
        ctx.font = `bold ${22 + Math.floor(Math.random() * 6)}px Poppins`;
        ctx.fillStyle = `rgba(0, 0, 0, ${0.8 + Math.random() * 0.2})`;
        ctx.fillText(char, 0, 0);
        ctx.restore();
    }

    document.getElementById("captcha-session").value = captchaCode;
}

function resetForm() {
    document.getElementById("username").value = "";
    document.getElementById("password").value = "";
    document.getElementById("captcha-input").value = "";
    generateCaptcha();
}

document.addEventListener("DOMContentLoaded", function () {
    generateCaptcha();
    
    // Tambahkan event listener untuk tombol refresh captcha
    const refreshButton = document.getElementById("refresh-captcha");
    if (refreshButton) {
        refreshButton.addEventListener("click", generateCaptcha);
    }
    
    const showPasswordCheckbox = document.getElementById("show-password");
    if (showPasswordCheckbox) {
        showPasswordCheckbox.addEventListener("change", function () {
            const passwordInput = document.getElementById("password");
            passwordInput.type = this.checked ? "text" : "password";
        });
    }
});