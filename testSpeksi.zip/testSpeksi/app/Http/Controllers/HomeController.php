<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient; // kalau data kes disimpan dalam table patients
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function index()
    {
        $currentYear = now()->year;
        $currentMonth = now()->month;

        // 📊 Kira jumlah kes setahun & bulan semasa
        $totalCasesYear = \App\Models\Patient::whereYear('created_at', $currentYear)->count();
        $totalCasesMonth = \App\Models\Patient::whereYear('created_at', $currentYear)
            ->whereMonth('created_at', $currentMonth)
            ->count();

        // 📈 KPI 1: Tindak balas dalam masa ≤ 2 hari
        $patients = \App\Models\Patient::whereYear('tarikh_rujukan', $currentYear)
            ->whereMonth('tarikh_rujukan', $currentMonth)
            ->get();

        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                $start = \Carbon\Carbon::parse($p->tarikh_rujukan);
                $end = \Carbon\Carbon::parse($p->tarikh_tindakbalas_awal);
                $workingDays = 0;

                for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                    if ($date->isWeekday()) {
                        $workingDays++;
                    }
                }

                return $workingDays <= 2;
            }
            return false;
        })->count();

        $percentageKpi1 = $patients->count() > 0
            ? round(($casesWithin2Days / $patients->count()) * 100, 2)
            : 0;

        // 📈 KPI 2: Laporan dihantar dalam masa ≤ 5 hari selepas dokumen lengkap diterima
        $patientsKpi2 = \App\Models\Patient::whereNotNull('tarikh_dokumen_lengkap')
            ->whereNotNull('tarikh_laporan')
            ->get();

        $within5Days = 0;

        foreach ($patientsKpi2 as $p) {
            if ($p->tarikh_dokumen_lengkap && $p->tarikh_laporan) {
                $start = \Carbon\Carbon::parse($p->tarikh_dokumen_lengkap);
                $end = \Carbon\Carbon::parse($p->tarikh_laporan);
                $workingDays = 0;

                for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                    if ($date->isWeekday()) {
                        $workingDays++;
                    }
                }

                if ($workingDays <= 5) {
                    $within5Days++;
                }
            }
        }

        $totalCasesKpi2 = $patientsKpi2->count();
        $percentageKpi2 = $totalCasesKpi2 > 0
            ? round(($within5Days / $totalCasesKpi2) * 100, 2)
            : 0;

        // Hantar semua data ke view
        return view('home', compact(
            'totalCasesYear',
            'totalCasesMonth',
            'casesWithin2Days',
            'percentageKpi1',
            'within5Days',
            'percentageKpi2'
        ));
    }

    public function userHome()
    {
        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        $totalCasesYear = Patient::whereYear('created_at', $currentYear)->count();
        $totalCasesMonth = Patient::whereYear('created_at', $currentYear)
            ->whereMonth('created_at', $currentMonth)
            ->count();

        // (Opsyenal: tambah kiraan KPI 1 juga kalau nak)
        return view('home', compact('totalCasesYear', 'totalCasesMonth'));
    }

    public function login()
    {
        return view('auth.login-custom');
    }
}
