<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient; // kalau data kes disimpan dalam table patients
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // Kalau admin, terus redirect ke dashboard admin
        if (strtolower($user->role) === 'admin') {
            return redirect()->route('admin.home');
        }

        // Kalau user biasa → kekal di home.blade.php
        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        // Kira jumlah kes tahun ini
        $totalCasesYear = Patient::whereYear('created_at', $currentYear)->count();

        // Kira jumlah kes bulan ini
        $totalCasesMonth = Patient::whereYear('created_at', $currentYear)
            ->whereMonth('created_at', $currentMonth)
            ->count();

        // 🔹 Ambil semua pesakit bulan semasa untuk kira KPI 1
        $patients = Patient::whereYear('tarikh_rujukan', $currentYear)
            ->whereMonth('tarikh_rujukan', $currentMonth)
            ->get();

        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                return Carbon::parse($p->tarikh_rujukan)
                    ->diffInDays(Carbon::parse($p->tarikh_tindakbalas_awal)) <= 2;
            }
            return false;
        })->count();

        $percentageKpi1 = $patients->count() > 0
            ? round(($casesWithin2Days / $patients->count()) * 100, 2)
            : 0;

        return view('home', compact(
            'totalCasesYear',
            'totalCasesMonth',
            'casesWithin2Days',
            'percentageKpi1'
        ));
    }

    public function userHome()
    {
        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        $totalCasesYear = Patient::whereYear('created_at', $currentYear)->count();
        $totalCasesMonth = Patient::whereYear('created_at', $currentYear)
            ->whereMonth('created_at', $currentMonth)
            ->count();

        // (Opsyenal: tambah kiraan KPI 1 juga kalau nak)
        return view('home', compact('totalCasesYear', 'totalCasesMonth'));
    }

    public function login()
    {
        return view('auth.login-custom');
    }
}
