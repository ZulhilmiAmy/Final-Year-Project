<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient; // guna patients table
use Carbon\Carbon;

class AppointmentController extends Controller
{
public function upcoming()
{
    $today = \Carbon\Carbon::today();

    $appointments = \App\Models\Patient::whereDate('tarikh_temu', '>=', $today)
        ->orderBy('tarikh_temu', 'asc')
        ->get();

    $formatted = $appointments->map(function ($patient) {
        return [
            'id'           => $patient->id,
            'patient_name' => $patient->nama,
            'date'         => $patient->tarikh_temu,   // hanya tarikh untuk paparan calendar
            'masa_temu'    => $patient->masa_temu,     // masa akan dipanggil dalam alert
            'title'        => $patient->nama,
            'start'        => $patient->tarikh_temu,   // jangan tambah masa di sini
            'pegawai_kes'  => $patient->pegawai_kes ?? 'Tidak Ditetapkan'
        ];
    });

    return response()->json($formatted);
}



}
