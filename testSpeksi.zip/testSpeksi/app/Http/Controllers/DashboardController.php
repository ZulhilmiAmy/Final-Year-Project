<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\CaseModel;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function totalCase()
    {
        $year = \Carbon\Carbon::now()->year;

        // Jumlah kes setahun
        $totalCasesYear = \App\Models\Patient::whereYear('created_at', $year)->count();

        // Semua kes ikut bulan
        $casesByMonth = \App\Models\Patient::selectRaw('MONTH(created_at) as month, COUNT(*) as total')
            ->whereYear('created_at', $year)
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        return view('admin.totalCase', compact('totalCasesYear', 'casesByMonth'));
    }
    public function homeAdmin()
    {
        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        // jumlah kes tahun & bulan semasa
        $totalCasesYear = Patient::whereYear('created_at', $currentYear)->count();
        $totalCasesMonth = Patient::whereYear('created_at', $currentYear)
            ->whereMonth('created_at', $currentMonth)
            ->count();

        // 🔹 Ambil semua pesakit bulan semasa untuk kira KPI 1
        $patients = Patient::whereYear('tarikh_rujukan', $currentYear)
            ->whereMonth('tarikh_rujukan', $currentMonth)
            ->get();

        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                return Carbon::parse($p->tarikh_rujukan)
                    ->diffInDays(Carbon::parse($p->tarikh_tindakbalas_awal)) <= 2;
            }
            return false;
        })->count();

        $percentageKpi1 = $patients->count() > 0
            ? round(($casesWithin2Days / $patients->count()) * 100, 2)
            : 0;

        return view('admin.homeAdmin', compact(
            'totalCasesYear',
            'totalCasesMonth',
            'casesWithin2Days',
            'percentageKpi1'
        ));
    }

    public function kpi1(Request $request)
    {
        $bulan = $request->query('bulan', now()->month); // default: bulan semasa
        $tahun = $request->query('tahun', now()->year);

        $patients = Patient::whereYear('tarikh_rujukan', $tahun)
            ->whereMonth('tarikh_rujukan', $bulan)
            ->get();

        $totalCases = $patients->count();
        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                return \Carbon\Carbon::parse($p->tarikh_rujukan)
                    ->diffInDays(\Carbon\Carbon::parse($p->tarikh_tindakbalas_awal)) <= 2;
            }
            return false;
        })->count();

        $percentage = $totalCases > 0 ? round(($casesWithin2Days / $totalCases) * 100, 2) : 0;

        return view('admin.kpi1', compact('patients', 'totalCases', 'casesWithin2Days', 'percentage', 'bulan', 'tahun'));
    }

    public function kpi1User(Request $request)
    {
        $bulan = $request->query('bulan', now()->month); // default bulan semasa
        $tahun = $request->query('tahun', now()->year);  // default tahun semasa

        $patients = Patient::whereYear('tarikh_rujukan', $tahun)
            ->whereMonth('tarikh_rujukan', $bulan)
            ->get();

        $totalCases = $patients->count();
        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                return Carbon::parse($p->tarikh_rujukan)
                    ->diffInDays(Carbon::parse($p->tarikh_tindakbalas_awal)) <= 2;
            }
            return false;
        })->count();

        $percentage = $totalCases > 0 ? round(($casesWithin2Days / $totalCases) * 100, 2) : 0;

        return view('admin.kpi1', compact(
            'patients',
            'totalCases',
            'casesWithin2Days',
            'percentage',
            'bulan',
            'tahun'
        ));
    }

    public function kpi2()
    {
        // Ambil semua pesakit yang ada kedua-dua tarikh (dokumen lengkap & laporan dihantar)
        $patients = \App\Models\Patient::whereNotNull('tarikh_dokumen_lengkap')
            ->whereNotNull('tarikh_laporan')
            ->get();

        $totalCases = $patients->count();
        $within5Days = 0;

        foreach ($patients as $p) {
            if ($p->tarikh_dokumen_lengkap && $p->tarikh_laporan) {
                $start = \Carbon\Carbon::parse($p->tarikh_dokumen_lengkap);
                $end = \Carbon\Carbon::parse($p->tarikh_laporan);
                $workingDays = 0;

                for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                    if ($date->isWeekday()) {
                        $workingDays++;
                    }
                }

                if ($workingDays <= 5) {
                    $within5Days++;
                }

                // Simpan ke dalam model supaya boleh access di view
                $p->working_days = $workingDays;
            }
        }

        $percentage = $totalCases > 0 ? round(($within5Days / $totalCases) * 100, 2) : 0;

        return view('admin.kpi2', compact('patients', 'totalCases', 'within5Days', 'percentage'));
    }
    public function updateAgency(Request $request)
    {
        $request->validate([
            'id' => 'required|exists:patients,id',
            'agensi' => 'nullable|string|max:255',
        ]);

        $patient = \App\Models\Patient::find($request->id);
        $patient->agensi = $request->agensi;
        $patient->save();

        return response()->json(['success' => true, 'message' => 'Agensi berjaya dikemaskini.']);
    }

}
