<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\CaseModel;
use Carbon\Carbon;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class DashboardController extends Controller
{
    public function totalCase()
    {
        $year = \Carbon\Carbon::now()->year;

        // Jumlah kes setahun
        $totalCasesYear = \App\Models\Patient::whereYear('created_at', $year)->count();

        // Semua kes ikut bulan
        $casesByMonth = \App\Models\Patient::selectRaw('MONTH(created_at) as month, COUNT(*) as total')
            ->whereYear('created_at', $year)
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        return view('admin.totalCase', compact('totalCasesYear', 'casesByMonth'));
    }
    public function homeAdmin()
    {
        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        // Jumlah kes tahun & bulan semasa
        $totalCasesYear = Patient::whereYear('created_at', $currentYear)->count();
        $totalCasesMonth = Patient::whereYear('created_at', $currentYear)
            ->whereMonth('created_at', $currentMonth)
            ->count();

        // ===== KPI 1 =====
        $patientsKpi1 = Patient::whereYear('tarikh_rujukan', $currentYear)
            ->whereMonth('tarikh_rujukan', $currentMonth)
            ->get();

        $casesWithin2Days = $patientsKpi1->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                $start = Carbon::parse($p->tarikh_rujukan);
                $end = Carbon::parse($p->tarikh_tindakbalas_awal);
                $workingDays = 0;
                for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                    if ($date->isWeekday()) {
                        $workingDays++;
                    }
                }
                return $workingDays <= 2;
            }
            return false;
        })->count();

        $percentageKpi1 = $patientsKpi1->count() > 0
            ? round(($casesWithin2Days / $patientsKpi1->count()) * 100, 2)
            : 0;

        // ===== KPI 2 =====
        $patientsKpi2 = Patient::whereNotNull('tarikh_dokumen_lengkap')
            ->whereNotNull('tarikh_laporan')
            ->get();

        $within5Days = 0;

        foreach ($patientsKpi2 as $p) {
            $start = Carbon::parse($p->tarikh_dokumen_lengkap);
            $end = Carbon::parse($p->tarikh_laporan);
            $workingDays = 0;

            for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                if ($date->isWeekday()) {
                    $workingDays++;
                }
            }

            if ($workingDays <= 5) {
                $within5Days++;
            }
        }

        $percentageKpi2 = $patientsKpi2->count() > 0
            ? round(($within5Days / $patientsKpi2->count()) * 100, 2)
            : 0;

        return view('admin.homeAdmin', compact(
            'totalCasesYear',
            'totalCasesMonth',
            'casesWithin2Days',
            'percentageKpi1',
            'within5Days',
            'percentageKpi2'
        ));
    }
    public function kpi1(Request $request)
    {
        $bulan = $request->query('bulan', now()->month);
        $tahun = $request->query('tahun', now()->year);

        // ✅ Ambil senarai tahun yang ada data dalam tarikh_rujukan
        $availableYears = Patient::selectRaw('YEAR(tarikh_rujukan) as year')
            ->whereNotNull('tarikh_rujukan')
            ->groupBy('year')
            ->orderBy('year', 'desc')
            ->pluck('year');

        // Dapatkan pesakit untuk bulan & tahun yang dipilih
        $patients = Patient::whereYear('tarikh_rujukan', $tahun)
            ->whereMonth('tarikh_rujukan', $bulan)
            ->get();

        $totalCases = $patients->count();

        // Kira kes yang siap dalam ≤2 hari bekerja
        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                $start = Carbon::parse($p->tarikh_rujukan);
                $end = Carbon::parse($p->tarikh_tindakbalas_awal);
                $workingDays = 0;

                for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                    if ($date->isWeekday()) {
                        $workingDays++;
                    }
                }

                return $workingDays <= 2;
            }
            return false;
        })->count();

        $percentage = $totalCases > 0
            ? round(($casesWithin2Days / $totalCases) * 100, 2)
            : 0;

        return view('admin.kpi1', compact(
            'patients',
            'totalCases',
            'casesWithin2Days',
            'percentage',
            'bulan',
            'tahun',
            'availableYears' // 🔹 Hantar ke Blade
        ));
    }


    public function kpi1User(Request $request)
    {
        $bulan = $request->query('bulan', now()->month); // default bulan semasa
        $tahun = $request->query('tahun', now()->year);  // default tahun semasa

        $patients = Patient::whereYear('tarikh_rujukan', $tahun)
            ->whereMonth('tarikh_rujukan', $bulan)
            ->get();

        $totalCases = $patients->count();
        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                return Carbon::parse($p->tarikh_rujukan)
                    ->diffInDays(Carbon::parse($p->tarikh_tindakbalas_awal)) <= 2;
            }
            return false;
        })->count();

        $percentage = $totalCases > 0 ? round(($casesWithin2Days / $totalCases) * 100, 2) : 0;

        return view('admin.kpi1', compact(
            'patients',
            'totalCases',
            'casesWithin2Days',
            'percentage',
            'bulan',
            'tahun'
        ));
    }

    public function kpi2(Request $request)
    {
        $bulan = $request->query('bulan', 'all'); // default: semua bulan
        $tahun = $request->query('tahun', now()->year);

        $query = Patient::query();

        // tapis ikut tahun (berdasarkan bila data dimasukkan)
        $query->whereYear('created_at', $tahun);

        // tapis ikut bulan jika bukan 'all'
        if ($bulan !== 'all') {
            $query->whereMonth('created_at', $bulan);
        }

        $patients = $query->get();

        $totalCases = $patients->count();
        $within5Days = 0;

        foreach ($patients as $p) {
            $p->working_days = null;
            if ($p->tarikh_dokumen_lengkap && $p->tarikh_laporan) {
                $start = \Carbon\Carbon::parse($p->tarikh_dokumen_lengkap);
                $end = \Carbon\Carbon::parse($p->tarikh_laporan);
                $workingDays = 0;
                for ($date = $start->copy(); $date->lte($end); $date->addDay()) {
                    if ($date->isWeekday()) {
                        $workingDays++;
                    }
                }
                $p->working_days = $workingDays;
                if ($workingDays <= 5) {
                    $within5Days++;
                }
            }
        }

        $validCases = $patients->filter(fn($p) => $p->tarikh_dokumen_lengkap && $p->tarikh_laporan)->count();
        $percentage = $validCases > 0 ? round(($within5Days / $validCases) * 100, 2) : 0;

        // senarai tahun berdasarkan bila data dimasukkan
        $availableYears = Patient::selectRaw('YEAR(created_at) as year')
            ->groupBy('year')
            ->orderBy('year', 'desc')
            ->pluck('year');

        return view('admin.kpi2', compact(
            'patients',
            'totalCases',
            'within5Days',
            'percentage',
            'bulan',
            'tahun',
            'availableYears'
        ));
    }
    public function updateAgency(Request $request)
    {
        $request->validate([
            'id' => 'required|exists:patients,id',
            'agensi' => 'nullable|string|max:255',
        ]);

        $patient = \App\Models\Patient::find($request->id);
        $patient->agensi = $request->agensi;
        $patient->save();

        return response()->json(['success' => true, 'message' => 'Agensi berjaya dikemaskini.']);
    }

    public function registerUser(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'username' => 'required|string|unique:users,username',
            'password' => 'required|string|min:6|confirmed',
            'role' => 'required|in:user,admin',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ], 422);
        }

        // Simpan user baru
        $user = User::create([
            'name' => strtoupper($request->name),
            'username' => $request->username,
            'email' => $request->username, // guna username juga untuk email
            'password' => Hash::make($request->password),
            'role' => $request->role,
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Pendaftaran pengguna berjaya!',
            'user_id' => $user->id
        ]);
    }

}
