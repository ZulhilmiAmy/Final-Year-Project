<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Patient;
use App\Models\CaseModel;
use Carbon\Carbon;

class DashboardController extends Controller
{
    // public function index()
    // {
    //     $year = Carbon::now()->year;
    //     $month = Carbon::now()->month;

    //     // Jumlah kes tahun ini
    //     $totalCasesYear = Patient::whereYear('created_at', $year)->count();

    //     // Jumlah kes bulan ini
    //     $totalCasesMonth = Patient::whereYear('created_at', $year)
    //         ->whereMonth('created_at', $month)
    //         ->count();

    //     return view('admin.homeAdmin', compact('totalCasesYear', 'totalCasesMonth'));
    // }

    public function totalCase()
    {
        $year = \Carbon\Carbon::now()->year;

        // Jumlah kes setahun
        $totalCasesYear = \App\Models\Patient::whereYear('created_at', $year)->count();

        // Semua kes ikut bulan
        $casesByMonth = \App\Models\Patient::selectRaw('MONTH(created_at) as month, COUNT(*) as total')
            ->whereYear('created_at', $year)
            ->groupBy('month')
            ->orderBy('month')
            ->get();

        return view('admin.totalCase', compact('totalCasesYear', 'casesByMonth'));
    }
    public function homeAdmin()
    {
        $currentYear = Carbon::now()->year;
        $currentMonth = Carbon::now()->month;

        // jumlah kes tahun & bulan semasa
        $totalCasesYear = Patient::whereYear('created_at', $currentYear)->count();
        $totalCasesMonth = Patient::whereYear('created_at', $currentYear)
            ->whereMonth('created_at', $currentMonth)
            ->count();

        // 🔹 Ambil semua pesakit bulan semasa untuk kira KPI 1
        $patients = Patient::whereYear('tarikh_rujukan', $currentYear)
            ->whereMonth('tarikh_rujukan', $currentMonth)
            ->get();

        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                return Carbon::parse($p->tarikh_rujukan)
                    ->diffInDays(Carbon::parse($p->tarikh_tindakbalas_awal)) <= 2;
            }
            return false;
        })->count();

        $percentageKpi1 = $patients->count() > 0
            ? round(($casesWithin2Days / $patients->count()) * 100, 2)
            : 0;

        return view('admin.homeAdmin', compact(
            'totalCasesYear',
            'totalCasesMonth',
            'casesWithin2Days',
            'percentageKpi1'
        ));
    }


    public function kpi1(Request $request)
    {
        $bulan = $request->query('bulan', now()->month); // default: bulan semasa
        $tahun = $request->query('tahun', now()->year);

        $patients = Patient::whereYear('tarikh_rujukan', $tahun)
            ->whereMonth('tarikh_rujukan', $bulan)
            ->get();

        $totalCases = $patients->count();
        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                return \Carbon\Carbon::parse($p->tarikh_rujukan)
                    ->diffInDays(\Carbon\Carbon::parse($p->tarikh_tindakbalas_awal)) <= 2;
            }
            return false;
        })->count();

        $percentage = $totalCases > 0 ? round(($casesWithin2Days / $totalCases) * 100, 2) : 0;

        return view('admin.kpi1', compact('patients', 'totalCases', 'casesWithin2Days', 'percentage', 'bulan', 'tahun'));
    }


    public function kpi1User()
    {
        $patients = Patient::whereYear('tarikh_rujukan', now()->year)
            ->whereMonth('tarikh_rujukan', now()->month)
            ->get();

        $totalCases = $patients->count();
        $casesWithin2Days = $patients->filter(function ($p) {
            if ($p->tarikh_rujukan && $p->tarikh_tindakbalas_awal) {
                return Carbon::parse($p->tarikh_rujukan)
                    ->diffInDays(Carbon::parse($p->tarikh_tindakbalas_awal)) <= 2;
            }
            return false;
        })->count();

        $percentage = $totalCases > 0 ? round(($casesWithin2Days / $totalCases) * 100, 2) : 0;

        // ❌ sebelum ni: return view('user.kpi1', ...)
        return view('admin.kpi1', compact('patients', 'totalCases', 'casesWithin2Days', 'percentage'));
    }



}
